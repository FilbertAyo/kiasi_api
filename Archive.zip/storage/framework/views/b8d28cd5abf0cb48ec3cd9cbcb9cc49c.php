

<?php /**PATH /Users/ayo/develop/daily_api/resources/views/layouts/navigation.blade.php ENDPATH**/ ?>