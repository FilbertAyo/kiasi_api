<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center">
            <h3>Static Content</h3>
            <a href="<?php echo e(route('admin.content.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle me-1"></i> Add Content
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <section class="section">
        
        <div class="alert alert-light-primary mb-4">
            <div class="d-flex align-items-start">
                <i class="bi bi-info-circle fs-4 me-3"></i>
                <div>
                    <h5 class="alert-heading">How Privacy & Terms Work</h5>
                    <p class="mb-2">These documents are legal agreements between you and your users:</p>
                    <ul class="mb-2">
                        <li><strong>Terms & Conditions</strong> - Rules users must follow to use your app</li>
                        <li><strong>Privacy Policy</strong> - How you collect, use, and protect user data</li>
                        <li><strong>About</strong> - Information about your company and app</li>
                    </ul>
                    <p class="mb-0"><strong>When to update:</strong> Update version when making significant changes. Users should be notified of major updates.</p>
                </div>
            </div>
        </div>

        <?php
            $typeLabels = [
                'terms' => ['label' => 'Terms & Conditions', 'icon' => 'bi-file-earmark-text', 'color' => 'primary'],
                'privacy' => ['label' => 'Privacy Policy', 'icon' => 'bi-shield-lock', 'color' => 'success'],
                'about' => ['label' => 'About', 'icon' => 'bi-info-circle', 'color' => 'info'],
            ];
        ?>

        <?php $__empty_1 = true; $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h4 class="card-title">
                        <i class="bi <?php echo e($typeLabels[$type]['icon'] ?? 'bi-file'); ?> text-<?php echo e($typeLabels[$type]['color'] ?? 'secondary'); ?> me-2"></i>
                        <?php echo e($typeLabels[$type]['label'] ?? ucfirst($type)); ?>

                    </h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Language</th>
                                    <th>Title</th>
                                    <th>Version</th>
                                    <th>Effective Date</th>
                                    <th>Status</th>
                                    <th>Last Updated</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <span class="badge bg-light-<?php echo e($content->language == 'en' ? 'primary' : 'warning'); ?>">
                                            <?php echo e($content->language == 'en' ? '🇬🇧 English' : '🇹🇿 Kiswahili'); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($content->title); ?></td>
                                    <td><code>v<?php echo e($content->version ?? '1.0'); ?></code></td>
                                    <td><?php echo e($content->effective_date ? $content->effective_date->format('M d, Y') : '-'); ?></td>
                                    <td>
                                        <?php if($content->is_active): ?>
                                            <span class="badge bg-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($content->updated_at->diffForHumans()); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('admin.content.edit', $content)); ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <form action="<?php echo e(route('admin.content.destroy', $content)); ?>" method="POST" 
                                                  onsubmit="return confirm('Are you sure you want to delete this content?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card">
                <div class="card-body text-center py-5">
                    <i class="bi bi-file-earmark-x display-1 text-muted"></i>
                    <h4 class="mt-3">No Content Found</h4>
                    <p class="text-muted">Start by adding your Terms & Conditions, Privacy Policy, and About content.</p>
                    <a href="<?php echo e(route('admin.content.create')); ?>" class="btn btn-primary">
                        <i class="bi bi-plus-circle me-1"></i> Add Content
                    </a>
                    <p class="text-muted mt-3">Or run the seeder: <code>php artisan db:seed --class=StaticContentSeeder</code></p>
                </div>
            </div>
        <?php endif; ?>

        
        <div class="card">
            <div class="card-header">
                <h4 class="card-title"><i class="bi bi-clock-history me-2"></i>Version Management Guide</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <h6><i class="bi bi-arrow-up-circle text-success me-1"></i> Minor Update (1.0 → 1.1)</h6>
                        <ul class="small text-muted">
                            <li>Typo fixes</li>
                            <li>Clarifications</li>
                            <li>Formatting changes</li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <h6><i class="bi bi-arrow-up-circle-fill text-warning me-1"></i> Major Update (1.x → 2.0)</h6>
                        <ul class="small text-muted">
                            <li>New data collection practices</li>
                            <li>Changed user rights</li>
                            <li>New third-party sharing</li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <h6><i class="bi bi-bell text-danger me-1"></i> Notify Users When</h6>
                        <ul class="small text-muted">
                            <li>Any privacy policy changes</li>
                            <li>Terms that affect user rights</li>
                            <li>Major feature changes</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>

<?php /**PATH /Users/ayo/develop/daily_api/resources/views/admin/content/index.blade.php ENDPATH**/ ?>