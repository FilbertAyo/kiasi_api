<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h3>Admin Dashboard</h3>
     <?php $__env->endSlot(); ?>

    <section class="row">
        <div class="col-12 col-lg-9">
            <div class="row">
                
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-4 py-4-5">
                            <div class="row">
                                <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                    <div class="stats-icon purple mb-2">
                                        <i class="bi bi-people-fill"></i>
                                    </div>
                                </div>
                                <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                    <h6 class="text-muted font-semibold">Total Users</h6>
                                    <h6 class="font-extrabold mb-0"><?php echo e(number_format($totalUsers)); ?></h6>
                                    <p class="text-muted mb-0">
                                        <span class="text-success"><?php echo e($activeUsers); ?></span> active,
                                        <span class="text-danger"><?php echo e($blockedUsers); ?></span> blocked
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-4 py-4-5">
                            <div class="row">
                                <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                    <div class="stats-icon blue mb-2">
                                        <i class="bi bi-receipt"></i>
                                    </div>
                                </div>
                                <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                    <h6 class="text-muted font-semibold">Transactions</h6>
                                    <h6 class="font-extrabold mb-0"><?php echo e(number_format($totalTransactions)); ?></h6>
                                    <p class="text-muted mb-0"><?php echo e($todayTransactions); ?> today</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-4 py-4-5">
                            <div class="row">
                                <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                    <div class="stats-icon green mb-2">
                                        <i class="bi bi-arrow-down-circle-fill"></i>
                                    </div>
                                </div>
                                <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                    <h6 class="text-muted font-semibold">Total Income</h6>
                                    <h6 class="font-extrabold mb-0 text-success">TZS <?php echo e(number_format($totalIncome)); ?></h6>
                                    <p class="text-muted mb-0">TZS <?php echo e(number_format($monthlyIncome)); ?> this month</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-4 py-4-5">
                            <div class="row">
                                <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                    <div class="stats-icon red mb-2">
                                        <i class="bi bi-arrow-up-circle-fill"></i>
                                    </div>
                                </div>
                                <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                    <h6 class="text-muted font-semibold">Total Expense</h6>
                                    <h6 class="font-extrabold mb-0 text-danger">TZS <?php echo e(number_format($totalExpense)); ?></h6>
                                    <p class="text-muted mb-0">TZS <?php echo e(number_format($monthlyExpense)); ?> this month</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Top Expense Categories (This Month)</h4>
                        </div>
                        <div class="card-body">
                            <?php $__empty_1 = true; $__currentLoopData = $categoryBreakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <span class="text-sm"><?php echo e($category['name']); ?></span>
                                        <span class="text-sm fw-bold">TZS <?php echo e(number_format($category['total'])); ?></span>
                                    </div>
                                    <?php
                                        $maxTotal = $categoryBreakdown->max('total');
                                        $percentage = $maxTotal > 0 ? ($category['total'] / $maxTotal) * 100 : 0;
                                    ?>
                                    <div class="progress progress-sm">
                                        <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo e($percentage); ?>%" 
                                             aria-valuenow="<?php echo e($percentage); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-muted">No expenses this month.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h4>Recent Transactions</h4>
                            <a href="<?php echo e(route('admin.transactions.index')); ?>" class="btn btn-sm btn-primary">View All</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-lg">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Category</th>
                                            <th>Type</th>
                                            <th>Amount</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="avatar avatar-md bg-light-primary me-3">
                                                            <span class="avatar-content"><?php echo e(substr($transaction->user->name ?? 'U', 0, 1)); ?></span>
                                                        </div>
                                                        <span><?php echo e($transaction->user->name ?? 'Unknown'); ?></span>
                                                    </div>
                                                </td>
                                                <td><?php echo e($transaction->category->name ?? 'Unknown'); ?></td>
                                                <td>
                                                    <span class="badge bg-light-<?php echo e($transaction->type === 'income' ? 'success' : 'danger'); ?>">
                                                        <?php echo e(ucfirst($transaction->type)); ?>

                                                    </span>
                                                </td>
                                                <td class="<?php echo e($transaction->type === 'income' ? 'text-success' : 'text-danger'); ?>">
                                                    TZS <?php echo e(number_format($transaction->amount)); ?>

                                                </td>
                                                <td><?php echo e($transaction->date->format('M d, Y')); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="5" class="text-center text-muted">No transactions yet.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-12 col-lg-3">
            
            <div class="card">
                <div class="card-body py-4 px-4">
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-xl bg-primary">
                            <span class="avatar-content fs-4"><?php echo e(substr(Auth::user()->name, 0, 1)); ?></span>
                        </div>
                        <div class="ms-3 name">
                            <h5 class="font-bold"><?php echo e(Auth::user()->name); ?></h5>
                            <h6 class="text-muted mb-0">Administrator</h6>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Recent Users</h4>
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-sm btn-light-primary">View All</a>
                </div>
                <div class="card-content pb-4">
                    <?php $__empty_1 = true; $__currentLoopData = $recentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="recent-message d-flex px-4 py-3">
                            <div class="avatar avatar-lg bg-light-primary">
                                <span class="avatar-content"><?php echo e(substr($user->name, 0, 1)); ?></span>
                            </div>
                            <div class="name ms-4">
                                <h5 class="mb-1"><?php echo e($user->name); ?></h5>
                                <h6 class="text-muted mb-0"><?php echo e($user->created_at->diffForHumans()); ?></h6>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="px-4 py-3">
                            <p class="text-muted mb-0">No users yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH /Users/ayo/develop/daily_api/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>