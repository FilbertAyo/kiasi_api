<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center">
            <h3>Categories Management</h3>
            <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Add Category
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <section class="section">
        <div class="row">
            
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">
                            <i class="bi bi-arrow-up-circle text-danger me-2"></i>
                            Expense Categories
                        </h4>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $categories->where('type', 'expense'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-center justify-content-between p-3 mb-3 rounded" 
                                 style="background-color: <?php echo e('#' . substr($category->color, 4, 6)); ?>15">
                                <div class="d-flex align-items-center">
                                    <div class="avatar avatar-lg me-3" style="background-color: <?php echo e('#' . substr($category->color, 4, 6)); ?>30">
                                      
                                    </div>
                                    <div>
                                        <h6 class="mb-0 fw-bold"><?php echo e($category->name); ?></h6>
                                        <small class="text-muted"><?php echo e($category->transactions_count); ?> transactions</small>
                                    </div>
                                </div>
                                <div class="d-flex gap-2">
                                    <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="btn btn-sm btn-light-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <?php if($category->transactions_count === 0): ?>
                                        <form method="POST" action="<?php echo e(route('admin.categories.destroy', $category)); ?>" 
                                              class="d-inline" onsubmit="return confirm('Are you sure you want to delete this category?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-light-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($categories->where('type', 'expense')->isEmpty()): ?>
                            <p class="text-muted text-center py-4">No expense categories yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">
                            <i class="bi bi-arrow-down-circle text-success me-2"></i>
                            Income Categories
                        </h4>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $categories->where('type', 'income'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-center justify-content-between p-3 mb-3 rounded" 
                                 style="background-color: <?php echo e('#' . substr($category->color, 4, 6)); ?>15">
                                <div class="d-flex align-items-center">
                                    <div class="avatar avatar-lg me-3" style="background-color: <?php echo e('#' . substr($category->color, 4, 6)); ?>30">
                                    </div>
                                    <div>
                                        <h6 class="mb-0 fw-bold"><?php echo e($category->name); ?></h6>
                                        <small class="text-muted"><?php echo e($category->transactions_count); ?> transactions</small>
                                    </div>
                                </div>
                                <div class="d-flex gap-2">
                                    <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="btn btn-sm btn-light-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <?php if($category->transactions_count === 0): ?>
                                        <form method="POST" action="<?php echo e(route('admin.categories.destroy', $category)); ?>" 
                                              class="d-inline" onsubmit="return confirm('Are you sure you want to delete this category?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-light-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($categories->where('type', 'income')->isEmpty()): ?>
                            <p class="text-muted text-center py-4">No income categories yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH /Users/ayo/develop/daily_api/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>