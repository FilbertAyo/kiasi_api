<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Seed default categories
        $this->call(CategorySeeder::class);

        // Seed app configuration
        $this->call(AppConfigSeeder::class);

        // Seed static content (terms, privacy, about)
        $this->call(StaticContentSeeder::class);

        // Seed FAQ
        $this->call(FaqSeeder::class);

        // Create admin user
        User::factory()->create([
            'name' => 'Admin User',
            'email' => 'admin@kiasidaily.com',
            'password' => Hash::make('password09'),
            'role' => 'admin',
        ]);

    }
}
