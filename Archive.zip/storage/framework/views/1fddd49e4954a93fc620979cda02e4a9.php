<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h3>Users Management</h3>
     <?php $__env->endSlot(); ?>

    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">All Users</h4>
            </div>
            <div class="card-body">
                
                <form method="GET" action="<?php echo e(route('admin.users.index')); ?>" class="mb-4">
                    <div class="row g-3">
                        <div class="col-md-5">
                            <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                                   placeholder="Search by name or email..."
                                   class="form-control">
                        </div>
                        <div class="col-md-3">
                            <select name="status" class="form-select">
                                <option value="">All Status</option>
                                <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                                <option value="blocked" <?php echo e(request('status') === 'blocked' ? 'selected' : ''); ?>>Blocked</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-search"></i> Filter
                            </button>
                            <?php if(request()->hasAny(['search', 'status'])): ?>
                                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-light-secondary">
                                    Clear
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>

                
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Status</th>
                                <th>Transactions</th>
                                <th>Joined</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar avatar-md bg-light-primary me-3">
                                                <span class="avatar-content"><?php echo e(substr($user->name, 0, 1)); ?></span>
                                            </div>
                                            <div>
                                                <p class="mb-0 fw-bold"><?php echo e($user->name); ?></p>
                                                <small class="text-muted"><?php echo e($user->email); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($user->is_blocked): ?>
                                            <span class="badge bg-light-danger">Blocked</span>
                                        <?php else: ?>
                                            <span class="badge bg-light-success">Active</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(number_format($user->transactions_count)); ?></td>
                                    <td><?php echo e($user->created_at->format('M d, Y')); ?></td>
                                    <td class="text-end">
                                        <a href="<?php echo e(route('admin.users.show', $user)); ?>" class="btn btn-sm btn-light-primary">
                                            <i class="bi bi-eye"></i> View
                                        </a>
                                        <?php if($user->is_blocked): ?>
                                            <form method="POST" action="<?php echo e(route('admin.users.unblock', $user)); ?>" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-light-success">
                                                    <i class="bi bi-unlock"></i> Unblock
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <form method="POST" action="<?php echo e(route('admin.users.block', $user)); ?>" class="d-inline" 
                                                  onsubmit="return confirm('Are you sure you want to block this user?')">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-light-danger">
                                                    <i class="bi bi-lock"></i> Block
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">
                                        No users found.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="mt-4">
                    <?php echo e($users->withQueryString()->links('pagination::bootstrap-5')); ?>

                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH /Users/ayo/develop/daily_api/resources/views/admin/users/index.blade.php ENDPATH**/ ?>