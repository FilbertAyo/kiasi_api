<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center">
            <h3>
                <i class="bi bi-<?php echo e($category->icon ?? 'folder'); ?> me-2"></i>
                <?php echo e($category->name_en); ?> - Questions
            </h3>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('admin.faq.questions.create', $category)); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-circle me-1"></i> Add Question
                </a>
                <a href="<?php echo e(route('admin.faq.index')); ?>" class="btn btn-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Back
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <section class="section">
        
        <div class="alert alert-light mb-4">
            <div class="row">
                <div class="col-md-6">
                    <strong>English:</strong> <?php echo e($category->name_en); ?>

                </div>
                <div class="col-md-6">
                    <strong>Kiswahili:</strong> <?php echo e($category->name_sw); ?>

                </div>
            </div>
        </div>

        <?php if($questions->count() > 0): ?>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h4 class="card-title">
                        <span class="me-2">🇬🇧</span> English Questions
                    </h4>
                </div>
                <div class="card-body">
                    <?php if(isset($questions['en']) && $questions['en']->count() > 0): ?>
                        <div class="accordion" id="accordionEnglish">
                            <?php $__currentLoopData = $questions['en']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" 
                                            data-bs-toggle="collapse" data-bs-target="#en<?php echo e($question->id); ?>">
                                        <span class="badge bg-light-secondary me-2">#<?php echo e($question->display_order); ?></span>
                                        <?php echo e($question->question); ?>

                                        <?php if(!$question->is_active): ?>
                                            <span class="badge bg-secondary ms-2">Inactive</span>
                                        <?php endif; ?>
                                    </button>
                                </h2>
                                <div id="en<?php echo e($question->id); ?>" class="accordion-collapse collapse" 
                                     data-bs-parent="#accordionEnglish">
                                    <div class="accordion-body">
                                        <p><?php echo e($question->answer); ?></p>
                                        <div class="d-flex justify-content-between align-items-center mt-3">
                                            <small class="text-muted">
                                                <i class="bi bi-hand-thumbs-up me-1"></i> <?php echo e($question->helpful_count ?? 0); ?> found helpful
                                            </small>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('admin.faq.questions.edit', $question)); ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-pencil me-1"></i> Edit
                                                </a>
                                                <form action="<?php echo e(route('admin.faq.questions.destroy', $question)); ?>" method="POST"
                                                      onsubmit="return confirm('Delete this question?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted mb-0">No English questions yet.</p>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">
                        <span class="me-2">🇹🇿</span> Kiswahili Questions
                    </h4>
                </div>
                <div class="card-body">
                    <?php if(isset($questions['sw']) && $questions['sw']->count() > 0): ?>
                        <div class="accordion" id="accordionSwahili">
                            <?php $__currentLoopData = $questions['sw']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" 
                                            data-bs-toggle="collapse" data-bs-target="#sw<?php echo e($question->id); ?>">
                                        <span class="badge bg-light-secondary me-2">#<?php echo e($question->display_order); ?></span>
                                        <?php echo e($question->question); ?>

                                        <?php if(!$question->is_active): ?>
                                            <span class="badge bg-secondary ms-2">Inactive</span>
                                        <?php endif; ?>
                                    </button>
                                </h2>
                                <div id="sw<?php echo e($question->id); ?>" class="accordion-collapse collapse" 
                                     data-bs-parent="#accordionSwahili">
                                    <div class="accordion-body">
                                        <p><?php echo e($question->answer); ?></p>
                                        <div class="d-flex justify-content-between align-items-center mt-3">
                                            <small class="text-muted">
                                                <i class="bi bi-hand-thumbs-up me-1"></i> <?php echo e($question->helpful_count ?? 0); ?> waliona inasaidia
                                            </small>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('admin.faq.questions.edit', $question)); ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-pencil me-1"></i> Hariri
                                                </a>
                                                <form action="<?php echo e(route('admin.faq.questions.destroy', $question)); ?>" method="POST"
                                                      onsubmit="return confirm('Futa swali hili?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted mb-0">Hakuna maswali ya Kiswahili bado.</p>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="card-body text-center py-5">
                    <i class="bi bi-chat-square-text display-1 text-muted"></i>
                    <h4 class="mt-3">No Questions Yet</h4>
                    <p class="text-muted">Add questions in both English and Kiswahili for this category.</p>
                    <a href="<?php echo e(route('admin.faq.questions.create', $category)); ?>" class="btn btn-primary">
                        <i class="bi bi-plus-circle me-1"></i> Add Question
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>

<?php /**PATH /Users/ayo/develop/daily_api/resources/views/admin/faq/category.blade.php ENDPATH**/ ?>