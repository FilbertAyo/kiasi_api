{{-- This navigation is no longer needed as Mazer uses sidebar navigation --}}
{{-- Kept for backwards compatibility if needed --}}
