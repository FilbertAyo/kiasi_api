<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h3>All Transactions</h3>
     <?php $__env->endSlot(); ?>

    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Transactions</h4>
            </div>
            <div class="card-body">
                
                <form method="GET" action="<?php echo e(route('admin.transactions.index')); ?>" class="mb-4">
                    <div class="row g-3">
                        <div class="col-md-2">
                            <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                                   placeholder="Search description..."
                                   class="form-control">
                        </div>
                        <div class="col-md-2">
                            <select name="user_id" class="form-select">
                                <option value="">All Users</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>" <?php echo e(request('user_id') == $user->id ? 'selected' : ''); ?>>
                                        <?php echo e($user->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="category_id" class="form-select">
                                <option value="">All Categories</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e(request('category_id') == $category->id ? 'selected' : ''); ?>>
                                        <?php echo e($category->name); ?> (<?php echo e($category->type); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="type" class="form-select">
                                <option value="">All Types</option>
                                <option value="expense" <?php echo e(request('type') === 'expense' ? 'selected' : ''); ?>>Expense</option>
                                <option value="income" <?php echo e(request('type') === 'income' ? 'selected' : ''); ?>>Income</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <input type="date" name="start_date" value="<?php echo e(request('start_date')); ?>"
                                   placeholder="Start Date" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <input type="date" name="end_date" value="<?php echo e(request('end_date')); ?>"
                                   placeholder="End Date" class="form-control">
                        </div>
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search"></i> Filter
                        </button>
                        <?php if(request()->hasAny(['search', 'user_id', 'category_id', 'type', 'start_date', 'end_date'])): ?>
                            <a href="<?php echo e(route('admin.transactions.index')); ?>" class="btn btn-light-secondary">
                                Clear
                            </a>
                        <?php endif; ?>
                    </div>
                </form>

                
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Category</th>
                                <th>Description</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($transaction->id); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.users.show', $transaction->user)); ?>" class="text-primary">
                                            <?php echo e($transaction->user->name ?? 'Unknown'); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($transaction->category->name ?? 'Unknown'); ?></td>
                                    <td><?php echo e(Str::limit($transaction->description, 40) ?? '-'); ?></td>
                                    <td>
                                        <span class="badge bg-light-<?php echo e($transaction->type === 'income' ? 'success' : 'danger'); ?>">
                                            <?php echo e(ucfirst($transaction->type)); ?>

                                        </span>
                                    </td>
                                    <td class="fw-bold <?php echo e($transaction->type === 'income' ? 'text-success' : 'text-danger'); ?>">
                                        TZS <?php echo e(number_format($transaction->amount)); ?>

                                    </td>
                                    <td><?php echo e($transaction->date->format('M d, Y')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        No transactions found.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="mt-4">
                    <?php echo e($transactions->withQueryString()->links('pagination::bootstrap-5')); ?>

                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH /Users/ayo/develop/daily_api/resources/views/admin/transactions/index.blade.php ENDPATH**/ ?>