<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h3>App Settings</h3>
     <?php $__env->endSlot(); ?>

    <section class="section">
        
        <?php if($settings->has('app')): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h4 class="card-title">
                    <i class="bi bi-app-indicator text-primary me-2"></i>
                    App Information
                </h4>
                <p class="text-muted mb-0">Manage app version and maintenance settings</p>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.settings.update', 'app')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <?php $appData = $settings['app']->value; ?>
                    
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">App Name</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($appData['name'] ?? 'Kiasi Daily'); ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Current Version <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="version" value="<?php echo e($appData['version'] ?? '1.0.0'); ?>" 
                                   placeholder="e.g., 1.0.0" required>
                            <small class="text-muted">Format: major.minor.patch (e.g., 1.2.3)</small>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Minimum Required Version</label>
                            <input type="text" class="form-control" name="minimum_version" value="<?php echo e($appData['minimum_version'] ?? '1.0.0'); ?>"
                                   placeholder="e.g., 1.0.0">
                            <small class="text-muted">Users below this version must update</small>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="force_update" name="force_update" value="1"
                                       <?php echo e(($appData['force_update'] ?? false) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="force_update">
                                    <strong>Force Update</strong>
                                    <br><small class="text-muted">Users must update to continue using the app</small>
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="maintenance_mode" name="maintenance_mode" value="1"
                                       <?php echo e(($appData['maintenance_mode'] ?? false) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="maintenance_mode">
                                    <strong>Maintenance Mode</strong>
                                    <br><small class="text-muted">Show maintenance message to all users</small>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Maintenance Message</label>
                        <textarea class="form-control" name="maintenance_message" rows="2" 
                                  placeholder="We're currently performing maintenance. Please try again later."><?php echo e($appData['maintenance_message'] ?? ''); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle me-1"></i> Save App Settings
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if($settings->has('support')): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h4 class="card-title">
                    <i class="bi bi-headset text-success me-2"></i>
                    Support Contact
                </h4>
                <p class="text-muted mb-0">Manage support contact information</p>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.settings.update', 'support')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <?php $supportData = $settings['support']->value; ?>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="bi bi-envelope me-1"></i> Email</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e($supportData['email'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="bi bi-telephone me-1"></i> Phone</label>
                            <input type="text" class="form-control" name="phone" value="<?php echo e($supportData['phone'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="bi bi-whatsapp me-1"></i> WhatsApp</label>
                            <input type="text" class="form-control" name="whatsapp" value="<?php echo e($supportData['whatsapp'] ?? ''); ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success">
                        <i class="bi bi-check-circle me-1"></i> Save Support Info
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if($settings->has('company')): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h4 class="card-title">
                    <i class="bi bi-building text-info me-2"></i>
                    Company Information
                </h4>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.settings.update', 'company')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <?php $companyData = $settings['company']->value; ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Company Name</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($companyData['name'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Website</label>
                            <input type="url" class="form-control" name="website" value="<?php echo e($companyData['website'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e($companyData['email'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Address</label>
                            <input type="text" class="form-control" name="address" value="<?php echo e($companyData['address'] ?? ''); ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-info">
                        <i class="bi bi-check-circle me-1"></i> Save Company Info
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if($settings->has('social')): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h4 class="card-title">
                    <i class="bi bi-share text-purple me-2"></i>
                    Social Media Links
                </h4>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.settings.update', 'social')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <?php $socialData = $settings['social']->value; ?>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="bi bi-facebook me-1"></i> Facebook</label>
                            <input type="url" class="form-control" name="facebook" value="<?php echo e($socialData['facebook'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="bi bi-twitter me-1"></i> Twitter</label>
                            <input type="url" class="form-control" name="twitter" value="<?php echo e($socialData['twitter'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="bi bi-instagram me-1"></i> Instagram</label>
                            <input type="url" class="form-control" name="instagram" value="<?php echo e($socialData['instagram'] ?? ''); ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-secondary">
                        <i class="bi bi-check-circle me-1"></i> Save Social Links
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if($settings->has('update_urls')): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h4 class="card-title">
                    <i class="bi bi-cloud-download text-danger me-2"></i>
                    App Store URLs
                </h4>
                <p class="text-muted mb-0">Where users download/update the app</p>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.settings.update', 'update_urls')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <?php $urlsData = $settings['update_urls']->value; ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="bi bi-google-play me-1"></i> Google Play Store URL</label>
                            <input type="url" class="form-control" name="android" value="<?php echo e($urlsData['android'] ?? ''); ?>"
                                   placeholder="https://play.google.com/store/apps/details?id=...">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="bi bi-apple me-1"></i> Apple App Store URL</label>
                            <input type="url" class="form-control" name="ios" value="<?php echo e($urlsData['ios'] ?? ''); ?>"
                                   placeholder="https://apps.apple.com/app/...">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-check-circle me-1"></i> Save Store URLs
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <div class="row">
            
            <?php if($settings->has('languages')): ?>
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4 class="card-title">
                            <i class="bi bi-translate text-warning me-2"></i>
                            Supported Languages
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Code</th>
                                        <th>Name</th>
                                        <th>Native Name</th>
                                        <th>Default</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $settings['languages']->value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><code><?php echo e($lang['code']); ?></code></td>
                                        <td><?php echo e($lang['name']); ?></td>
                                        <td><?php echo e($lang['native_name']); ?></td>
                                        <td>
                                            <?php if($lang['is_default'] ?? false): ?>
                                                <span class="badge bg-success">Default</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            
            <?php if($settings->has('currencies')): ?>
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4 class="card-title">
                            <i class="bi bi-currency-exchange text-success me-2"></i>
                            Supported Currencies
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Code</th>
                                        <th>Symbol</th>
                                        <th>Name</th>
                                        <th>Default</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $settings['currencies']->value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><code><?php echo e($currency['code']); ?></code></td>
                                        <td><?php echo e($currency['symbol']); ?></td>
                                        <td><?php echo e($currency['name']); ?></td>
                                        <td>
                                            <?php if($currency['is_default'] ?? false): ?>
                                                <span class="badge bg-success">Default</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        
        <?php if($settings->has('date_formats')): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h4 class="card-title">
                    <i class="bi bi-calendar3 text-primary me-2"></i>
                    Date Formats
                </h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php $__currentLoopData = $settings['date_formats']->value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $format): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-2">
                        <div class="p-3 rounded <?php echo e(($format['is_default'] ?? false) ? 'bg-light-primary' : 'bg-light'); ?>">
                            <code><?php echo e($format['format']); ?></code>
                            <br>
                            <small class="text-muted">Example: <?php echo e($format['example']); ?></small>
                            <?php if($format['is_default'] ?? false): ?>
                                <span class="badge bg-primary ms-2">Default</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        
        <div class="alert alert-light border">
            <i class="bi bi-info-circle me-2"></i>
            <strong>Note:</strong> Languages, Currencies, and Date Formats are read-only. To modify these, run: 
            <code>php artisan db:seed --class=AppConfigSeeder</code>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH /Users/ayo/develop/daily_api/resources/views/admin/settings/index.blade.php ENDPATH**/ ?>